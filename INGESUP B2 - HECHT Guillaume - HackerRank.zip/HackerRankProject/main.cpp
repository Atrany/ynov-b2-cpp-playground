//Say "Hello, World!" With C++

#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    printf("Hello, World!");
    return 0;
}

//Input and Output

/*
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int a;
    int b;
    int c;
    cin >> a >> b >> c;
    cout << a+b+c << endl;
    return 0;
}*/

//Basic Data Types

/*
#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    int a;
    long b;
    char c;
    float d;
    double e;
    cin >> a >> b >> c >> d >> e;
    printf ("%d \n", a);
    printf ("%ld \n", b);
    printf ("%c \n", c);
    printf ("%f \n", d);
    printf ("%lf \n", e);
    return 0;
}
 */

//Conditional Statements

/*
#include <map>
#include <set>
#include <list>
#include <cmath>
#include <ctime>
#include <deque>
#include <queue>
#include <stack>
#include <string>
#include <bitset>
#include <cstdio>
#include <limits>
#include <vector>
#include <climits>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <numeric>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <unordered_map>

using namespace std;


int main(){
    int n;
    string num[10] = {"Greater than 9", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
    cin >> n;
    if (n > 9){
       cout << num[0];
    }else {
       cout << num[n];
    }
    return 0;
}
 */

//For Loop

/*
#include <iostream>
#include <cstdio>
using namespace std;

int main(){
    string num[9] = {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
    int min, max;
    cin >> min >> max;
    for (int i = min; i <= max; i++){
        if (i <= 9){
            cout << num[i-1];
            printf ("\n");
        }else {
            if (i%2 == 0){
                cout << "even \n";
        }else {
            cout << "odd \n";
        }
        }
    }
    return 0;
}
 */

//Functions

/*
#include <iostream>
#include <cstdio>
using namespace std;


Add `int max_of_four(int a, int b, int c, int d)` here.


int max_of_four (int a, int b, int c, int d){
    int num[3] = {b, c, d};
    int result = a;
    for (int i = 0; i <3; i++){
        if (result<num[i]){
            result =num[i];
        }
    }
    return result;
}

int main() {
    int a, b, c, d;
    scanf("%d %d %d %d", &a, &b, &c, &d);
    int ans = max_of_four(a, b, c, d);
    printf("%d", ans);

    return 0;
}
 */

//Pointer

/*
#include <stdio.h>
#include <cmath>

void update(int *a,int *b) {
    int c, d;
    c = *a+*b;
    d= abs(*a-*b);
    *a = c;
    *b = d;
}

int main() {
    int a, b;
    int *pa = &a, *pb = &b;

    scanf("%d %d", &a, &b);
    update(pa, pb);
    printf("%d\n%d", a, b);

    return 0;
}*/

//Arrays Introduction

/*#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    *//* Enter your code here. Read input from STDIN. Print output to STDOUT *//*
    int num;
    cin >> num;
    int tab[num];
    for (int i = 0; i<num; i++){
        cin >> tab[i];
    }
    for (int i = num-1; i>=0; i--){
        cout << tab[i];
        printf (" ");
    }
    return 0;
}*/

//Variable Sized Arrays

/*#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int N, Q;
    cin >> N >> Q;
    int **Sequence = new int*[N];
    for (int i = 0; i < N; i++) {
        int k;
        cin >> k;
        int *seq = new int[k];
        for (int j = 0; j < k; j++) {
            cin >> seq[j];
        }
        Sequence[i] = seq;
    }
    for (int i = 0; i < Q; i++) {
        int j, k;
        cin >> j >> k;
        cout << Sequence[j][k] << endl;
    }
    return 0;
}*/

//Strings

/*
#include <iostream>
#include <string>
using namespace std;

int main() {
    string a, b;
    cin >> a >> b;
    cout << a.size() << " " << b.size() << endl;
    cout << a + b << endl;
    char firstA = a[0], firstB = b[0];
    b[0] = firstA;
    a[0] = firstB;
    cout << a << " " << b << endl;

    return 0;
}*/

//StringStream

/*
#include <sstream>
#include <vector>
#include <iostream>
using namespace std;

vector<int> parseInts(string str) {
    vector<int> temp;
    char tempChar;
    int tempInt;
    stringstream s(str);
    while(s >> tempInt) {
        temp.push_back(tempInt);
        s >> tempChar;
    }
    return temp;
}


int main() {
    string str;
    cin >> str;
    vector<int> integers = parseInts(str);
    for(int i = 0; i < integers.size(); i++) {
        cout << integers[i] << "\n";
    }

    return 0;
}*/

//Structs

/*#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

struct Student {
    int age;
    string first_name;
    string last_name;
    int standard;
};

int main() {
    Student st;

    cin >> st.age >> st.first_name >> st.last_name >> st.standard;
    cout << st.age << " " << st.first_name << " " << st.last_name << " " << st.standard;

    return 0;
}*/

//Class

/*
#include <iostream>
#include <sstream>
using namespace std;

class Student {
private:
    int age;
    string first_name;
    string last_name;
    int standard;

public:
    int get_age() {
        return age;
    }
    void set_age(int a) {
        age = a;
    }
    string get_first_name () {
        return first_name;
    }
    void set_first_name(string f) {
        first_name = f;
    }
    string get_last_name () {
        return last_name;
    }
    void set_last_name (string l) {
        last_name = l;
    }
    int get_standard () {
        return standard;
    }
    void set_standard (int s) {
        standard = s;
    }
    string to_string() {
        return "" + std::to_string(age) + ',' + first_name + ',' + last_name + ',' + std::to_string(standard);
    }
};

int main() {
    int age, standard;
    string first_name, last_name;

    cin >> age >> first_name >> last_name >> standard;

    Student st;
    st.set_age(age);
    st.set_standard(standard);
    st.set_first_name(first_name);
    st.set_last_name(last_name);

    cout << st.get_age() << "\n";
    cout << st.get_last_name() << ", " << st.get_first_name() << "\n";
    cout << st.get_standard() << "\n";
    cout << "\n";
    cout << st.to_string();

    return 0;
}*/

//Classes and Objects

/*
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cassert>
using namespace std;

class Student {
private:
    int scores[5];
public:
    void input() {
        for (int i = 0; i < 5; i++) {
            cin >> scores[i];
        }
    }
    int calculateTotalScore() {
        int counter = 0;
        for (int i = 0; i < 5; i++) {
            counter += scores[i];
        }
        return counter;
    }
};

int main() {
    int n; // number of students
    cin >> n;
    Student *s = new Student[n]; // an array of n students

    for(int i = 0; i < n; i++){
        s[i].input();
    }

    // calculate kristen's score
    int kristen_score = s[0].calculateTotalScore();

    // determine how many students scored higher than kristen
    int count = 0;
    for(int i = 1; i < n; i++){
        int total = s[i].calculateTotalScore();
        if(total > kristen_score){
            count++;
        }
    }

    // print result
    cout << count;

    return 0;
}*/

//Box It!

/*
#include<bits/stdc++.h>

using namespace std;

class Box {
private:
    int length, breadth, height;
public:
    Box() {
        length = 0;
        breadth = 0;
        height = 0;
    }
    Box(int l, int b, int h) {
        length = l;
        breadth = b;
        height = h;
    }
    Box(const Box &B) {
        length = B.length;
        breadth = B.breadth;
        height = B.height;
    }
    int getLength() {
        return length;
    }
    int getBreadth() {
        return breadth;
    }
    int getHeight() {
        return height;
    }
    long long CalculateVolume() {
        return (long long)(breadth) * length * height;
    }
    bool operator<(Box &B) {
        if (length < B.length) {
            return true;
        } else if (length == B.length) {
            if (breadth < B.breadth) {
                return true;
            } else if (breadth == B.breadth) {
                if (height < B.height) {
                    return true;
                }
            }
        }

        return false;
    }
};
ostream &operator<<(ostream &out, Box &B) {
    out << B.getLength() << " " << B.getBreadth() << " " << B.getHeight();
    return out;
};

void check2()
{
    int n;
    cin>>n;
    Box temp;
    for(int i=0;i<n;i++)
    {
        int type;
        cin>>type;
        if(type ==1)
        {
            cout<<temp<<endl;
        }
        if(type == 2)
        {
            int l,b,h;
            cin>>l>>b>>h;
            Box NewBox(l,b,h);
            temp=NewBox;
            cout<<temp<<endl;
        }
        if(type==3)
        {
            int l,b,h;
            cin>>l>>b>>h;
            Box NewBox(l,b,h);
            if(NewBox<temp)
            {
                cout<<"Lesser\n";
            }
            else
            {
                cout<<"Greater\n";
            }
        }
        if(type==4)
        {
            cout<<temp.CalculateVolume()<<endl;
        }
        if(type==5)
        {
            Box NewBox(temp);
            cout<<NewBox<<endl;
        }

    }
}

int main()
{
    check2();
}*/

//Inherited Code

/*
#include <iostream>
#include <string>
#include <sstream>
#include <exception>
using namespace std;

class BadLengthException: public std::exception {
private:
    int length;
public:
    BadLengthException(int n) {
        length = n;
    }

    virtual string what() {
        return to_string(length);
    }
};

bool checkUsername(string username) {
    bool isValid = true;
    int n = username.length();
    if(n < 5) {
        throw BadLengthException(n);
    }
    for(int i = 0; i < n-1; i++) {
        if(username[i] == 'w' && username[i+1] == 'w') {
            isValid = false;
        }
    }
    return isValid;
}

int main() {
    int T; cin >> T;
    while(T--) {
        string username;
        cin >> username;
        try {
            bool isValid = checkUsername(username);
            if(isValid) {
                cout << "Valid" << '\n';
            } else {
                cout << "Invalid" << '\n';
            }
        } catch (BadLengthException e) {
            cout << "Too short: " << e.what() << '\n';
        }
    }
    return 0;
}*/

//Exceptional Server

/*
#include <iostream>
#include <exception>
#include <string>
#include <stdexcept>
#include <vector>
#include <cmath>
using namespace std;

class Server {
private:
    static int load;
public:
    static int compute(long long A, long long B) {
        load += 1;
        if(A < 0) {
            throw std::invalid_argument("A is negative");
        }
        vector<int> v(A, 0);
        int real = -1, cmplx = sqrt(-1);
        if(B == 0) throw 0;
        real = (A/B)*real;
        int ans = v.at(B);
        return real + A - B*ans;
    }
    static int getLoad() {
        return load;
    }
};
int Server::load = 0;

int main() {
    int T; cin >> T;
    while(T--) {
        long long A, B;
        cin >> A >> B;
        try {
            cout << Server::compute(A, B) << "\n";
        } catch (const std::bad_alloc& e) {
            cout << "Not enough memory\n";
        } catch (const std::exception& e) {
            cout << "Exception: " << e.what() << "\n";
        } catch (...) {
            cout << "Other Exception\n";
        }
    }
    cout << Server::getLoad() << endl;
    return 0;
}*/

//Abstract Classes - Polymorphism

/*
#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include <set>
#include <cassert>
using namespace std;

struct Node{
    Node* next;
    Node* prev;
    int value;
    int key;
    Node(Node* p, Node* n, int k, int val):prev(p),next(n),key(k),value(val){};
    Node(int k, int val):prev(NULL),next(NULL),key(k),value(val){};
};

class Cache{

protected:
    map<int,Node*> mp;
    int cp;
    Node* tail;
    Node* head;
    virtual void set(int, int) = 0;
    virtual int get(int) = 0;

};

class LRUCache: Cache {
public:
    LRUCache(int l) {
        cp = l;
        tail = NULL;
        head = NULL;
        mp = {};
    }
    virtual void set(int k, int v) {
        auto it = mp.find(k);
        if (it == mp.end()) {
            Node *node = new Node(k, v);
            if (cp == 0) {
                node->next = head;
                head->prev = node;
                head = node;
                Node *tmp = tail;
                mp.erase(tmp->key);
                tail = tail->prev;
                delete tmp;
            } else {
                cp--;
                if (head == NULL) {
                    head = node;
                    tail = node;
                } else {
                    node->next = head;
                    head->prev = node;
                    head = node;
                }
            }
            mp[k] = node;
        } else {
            Node *tmp = it->second;
            if (tmp != head) {
                if (tmp == tail) {
                    tail = tmp->prev;
                    tmp->prev->next = NULL;
                    tmp->prev = NULL;
                    tmp->next = head;
                    head->prev = tmp;
                    head = tmp;
                } else {
                    tmp->prev->next = tmp->next;
                    tmp->next->prev = tmp->prev;
                    tmp->prev = NULL;
                    tmp->next = head;
                    head->prev = tmp;
                    head = tmp;
                }
            }
            head->value = v;
        }
    }
    virtual int get(int k) {
        auto it = mp.find(k);
        if (it != mp.end()) {
            return it->second->value;
        }
        return -1;
    }
};

int main() {
    int n, capacity,i;
    cin >> n >> capacity;
    LRUCache l(capacity);
    for(i=0;i<n;i++) {
        string command;
        cin >> command;
        if(command == "get") {
            int key;
            cin >> key;
            cout << l.get(key) << endl;
        }
        else if(command == "set") {
            int key, value;
            cin >> key >> value;
            l.set(key,value);
        }
    }
    return 0;
}*/

//Vector-Sort

/*#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int n;
    cin >> n;
    vector<int> numbers(n, 0);
    for (int i = 0; i < n; i++) {
        cin >> numbers[i];
    }

    sort(numbers.begin(), numbers.end());

    for (int i = 0; i < n; i++) {
        cout << numbers[i] << " ";
    }
    return 0;
}*/

//Lower Bound-STL

/*#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int n, q;
    vector<int> numbers;
    cin >> n;
    for (int i = 0; i < n; i++) {
        int tmp;
        cin >> tmp;
        numbers.push_back(tmp);
    }
    cin >> q;
    for (int i = 0; i < q; i++) {
        int s;
        cin >> s;
        auto low = lower_bound(numbers.begin(), numbers.end(), s);
        int index = (low - numbers.begin());
        if (s == numbers[index]) {
            cout << "Yes " << index + 1 << "\n";
        } else {
            cout << "No " << index + 1 << "\n";
        }
    }
    return 0;
}*/

//Sets-STL

/*
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <set>
#include <algorithm>
using namespace std;


int main() {
    int n;
    cin >> n;
    set<int> s;
    for (int i = 0; i < n; i++) {
        int type;
        int value;
        cin >> type >> value;
        if (type == 1) {
            s.insert(value);
        } else if (type == 2) {
            s.erase(value);
        } else if (type == 3) {
            auto it = s.find(value);
            if (it != s.end()) {
                cout << "Yes\n";
            } else {
                cout << "No\n";
            }
        }
    }
    return 0;
}*/

//Maps-STL

/*#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <set>
#include <map>
#include <algorithm>
using namespace std;


int main() {
    int n;
    cin >> n;
    map<string,int> m;
    for (int i = 0; i < n; i++) {
        int type, mark;
        string name;
        cin >> type >> name;
        if (type == 1) {
            cin >> mark;
            auto it = m.find(name);
            if (it != m.end()) {
                m[name] += mark;
            } else {
                m[name] = mark;
            }
        } else if (type == 2) {
            m.erase(name);
        } else if (type == 3) {
            auto it = m.find(name);
            if (it != m.end()) {
                cout << m[name] << "\n";
            } else {
                cout << "0\n";
            }
        }
    }
    return 0;
}*/

//Inheritance Introduction

/*#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


class Triangle{
public:
    void triangle(){
        cout<<"I am a triangle\n";
    }
};
class Isosceles : public Triangle{
public:
    void isosceles(){
        cout<<"I am an isosceles triangle\n";
    }
    void description() {
        cout << "In an isosceles triangle two sides are equal\n";
    }
};
int main(){
    Isosceles isc;
    isc.isosceles();
    isc.description();
    isc.triangle();
    return 0;
}*/

//Rectangle Area

/*
#include <iostream>

using namespace std;

class Rectangle {
public:
    int width, height;
    Rectangle(){}
    void display() {
        cout << width << " " << height << "\n";
    }
};

class RectangleArea : public Rectangle {
public:
    RectangleArea(){}
    void read_input() {
        cin >> width;
        cin >> height;
    }
    void display() {
        cout << width * height << "\n";
    }
};

int main()
{
    RectangleArea r_area;

    r_area.read_input();

    r_area.Rectangle::display();

    r_area.display();

    return 0;
}*/

//Multi Level Inheritance

/*
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

class Triangle{
public:
    void triangle(){
        cout<<"I am a triangle\n";
    }
};

class Isosceles : public Triangle{
public:
    void isosceles(){
        cout<<"I am an isosceles triangle\n";
    }
};

class Equilateral : public Isosceles{
public:
    void equilateral(){
        cout<<"I am an equilateral triangle\n";
    }
};


//Write your code here.
int main(){

    Equilateral eqr;
    eqr.equilateral();
    eqr.isosceles();
    eqr.triangle();
    return 0;
}*/

//Accessing Inherited Functions

/*
#include<iostream>

using namespace std;

class A
{
public:
    A(){
        callA = 0;
    }
private:
    int callA;
    void inc(){
        callA++;
    }

protected:
    void func(int & a)
    {
        a = a * 2;
        inc();
    }
public:
    int getA(){
        return callA;
    }
};

class B
{
public:
    B(){
        callB = 0;
    }
private:
    int callB;
    void inc(){
        callB++;
    }
protected:
    void func(int & a)
    {
        a = a * 3;
        inc();
    }
public:
    int getB(){
        return callB;
    }
};

class C
{
public:
    C(){
        callC = 0;
    }
private:
    int callC;
    void inc(){
        callC++;
    }
protected:
    void func(int & a)
    {
        a = a * 5;
        inc();
    }
public:
    int getC(){
        return callC;
    }
};

class D : A, B, C
{

    int val;
public:
    D()
    {
        val = 1;
    }

    void update_val(int new_val)
    {
        int tmp = new_val;
        while (0 <= tmp / 2 && tmp%2 == 0) {
            A::func(val);
            tmp = tmp / 2;
        }

        while (0 <= tmp / 3 && tmp% 3 == 0) {
            B::func(val);
            tmp = tmp / 3;
        }

        while (0 <= tmp / 5 && tmp% 5 == 0) {
            C::func(val);
            tmp = tmp / 5;
        }
    }
    void check(int);
};

void D::check(int new_val)
{
    update_val(new_val);
    cout << "Value = " << val << endl << "A's func called " << getA() << " times " << endl << "B's func called " << getB() << " times" << endl << "C's func called " << getC() << " times" << endl;
}


int main()
{
    D d;
    int new_val;
    cin >> new_val;
    d.check(new_val);

}*/

//C++ Class Templates

/*
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cassert>
using namespace std;

template <class T>
class AddElements {
public:
    T element;
    AddElements (T arg) {element=arg;}
    T add(T el2) {
        return element + el2;
    }
};

template <>
class AddElements <string> {
public:
    string element;
    AddElements (string arg) {element=arg;}
    string concatenate (string el2) {
        return element + el2;
    }
};

int main () {
    int n,i;
    cin >> n;
    for(i=0;i<n;i++) {
        string type;
        cin >> type;
        if(type=="float") {
            double element1,element2;
            cin >> element1 >> element2;
            AddElements<double> myfloat (element1);
            cout << myfloat.add(element2) << endl;
        }
        else if(type == "int") {
            int element1, element2;
            cin >> element1 >> element2;
            AddElements<int> myint (element1);
            cout << myint.add(element2) << endl;
        }
        else if(type == "string") {
            string element1, element2;
            cin >> element1 >> element2;
            AddElements<string> mystring (element1);
            cout << mystring.concatenate(element2) << endl;
        }
    }
    return 0;
}*/

//Preprocessor Solution

/*#define INF INT8_MAX
#define FUNCTION(name,operator) void name(int &current, int candidate) {!(current operator candidate) ? current = candidate : false;}
#define io(v) cin>>v
#define toStr(str) #str
#define foreach(v, i) for (int i = 0; i < v.size(); ++i)

#include <iostream>
#include <vector>
using namespace std;

#if !defined toStr || !defined io || !defined FUNCTION || !defined INF
#error Missing preprocessor definitions
#endif

FUNCTION(minimum, <)
FUNCTION(maximum, >)

int main(){
    int n; cin >> n;
    vector<int> v(n);
    foreach(v, i) {
        io(v)[i];
    }
    int mn = INF;
    int mx = -INF;
    foreach(v, i) {
        minimum(mn, v[i]);
        maximum(mx, v[i]);
    }
    int ans = mx - mn;
    cout << toStr(Result =) <<' '<< ans;
    return 0;

}*/

//Overload Operators

/*#include<iostream>

using namespace std;

class Complex
{
public:
    int a,b;
    void input(string s)
    {
        int v1=0;
        int i=0;
        while(s[i]!='+')
        {
            v1=v1*10+s[i]-'0';
            i++;
        }
        while(s[i]==' ' || s[i]=='+'||s[i]=='i')
        {
            i++;
        }
        int v2=0;
        while(i<s.length())
        {
            v2=v2*10+s[i]-'0';
            i++;
        }
        a=v1;
        b=v2;
    }
};

Complex operator +(Complex f, Complex s) {
    Complex z;
    z.a = f.a + s.a;
    z.b = f.b + s.b;

    return z;
}

ostream& operator <<(ostream& os, Complex &z) {
    cout << "" << z.a << "+" << "i" << z.b;
    return os;
}

int main()
{
    Complex x,y;
    string s1,s2;
    cin>>s1;
    cin>>s2;
    x.input(s1);
    y.input(s2);
    Complex z=x+y;
    cout<<z<<endl;
}*/